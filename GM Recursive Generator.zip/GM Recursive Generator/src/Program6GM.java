//Program6GM.java: Populates array with 100 random numbers and prints array recursively
//CSIS 212-D01
//Citations: Deitel & Deitel, Java How to Program, 18.5 Example Using Recursion: Fibonacci Series

//import random package
import java.util.Random;

public class Program6GM {

    public static void main (String [] args){
        System.out.println("CSIS 312, Student Gina Monti - Assignment 6");
        System.out.println("Printing array recursively.  Format: index) array content");

        //array & random intialization
        int[] array = new int[100];

        Random randomNum = new Random();

        //randomly assigns integers between 1 and 100 in an array
        for (int i = 0; i < array.length; i++ ){
            array[i] = 1 + randomNum.nextInt(99);
        }

        //method call using array and index of 0 as arguments
        printArray(array, 0);
    }

    //printArray method
    public static void printArray(int[] inputArray, int i){
        //base case of inputArray.length
        if (i >= inputArray.length){
            return;
        }
        //recursive method call for else statement
        else{
            System.out.printf("%d) %d ", i, inputArray[i]);
            printArray(inputArray, i + 1);
        }
    }
}
