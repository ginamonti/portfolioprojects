﻿namespace CSIS209_Assignment_6_GM
{
    internal class Expenditure
    {
    }
}