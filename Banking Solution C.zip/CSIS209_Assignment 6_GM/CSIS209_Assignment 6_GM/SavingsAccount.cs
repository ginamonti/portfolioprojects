﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSIS209_Assignment_6_GM
{
    class SavingsAccount : Accounts
      
    {
        //properties
        private decimal InterestRate;
     


        //constructors
        public SavingsAccount()       
            : base()
        {
            setInterestRate(InterestRate);
        }


        //setter & getter
        public void setInterestRate (decimal ratePassedIn)
        {

            InterestRate = ratePassedIn;

            if (ratePassedIn < 0)
            {
                ratePassedIn = 0;
            }

           
        }

        public decimal getInterestRate()
        {
            return InterestRate;
        }

        //methods

        public decimal CalculateInterest()
        {
            decimal amountInterest = 0;
            decimal interestTotal = 0;
            amountInterest = base.getBalance() * getInterestRate();
            interestTotal = amountInterest + base.getBalance();
            return interestTotal;
        }


        public override void PrintAccount()
        {        
            base.PrintAccount();
            Console.WriteLine($"Interest rate: {getInterestRate().ToString("P0")}");
        }
    }
}
