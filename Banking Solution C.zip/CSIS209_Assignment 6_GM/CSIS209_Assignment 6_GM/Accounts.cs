﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSIS209_Assignment_6_GM
{
    class Accounts
    {
        //properties
        private decimal Balance;
        private string AccountName;
        private int AccountNumber;

        //constructors

        public Accounts()
        {
           
        }

  
        public Accounts(decimal Balance, string AccountName, int AccountNumber)
        {
            if (Balance >= 0.0M)
            {
                setBalance(Balance);
            }
            else Balance = 0;

            setAccountName(AccountName);
            setAccountNumber(AccountNumber);
        }

        //setters and getters

        public void setBalance(decimal setBalance)
        {
            Balance = setBalance;
        }

        public decimal getBalance()
        {            
            return Balance;
        }

        public void setAccountName(string setAccountName)
        {
            AccountName = setAccountName;

        }

        public string getAccountName()
        {
            return AccountName;   
        }

        public void setAccountNumber(int setAccountNumber)
        {
        AccountNumber = setAccountNumber;

        }

        public int getAccountNumber()
        {
        return AccountNumber;
        }


        //Base credit method
        public virtual decimal Credit(decimal Deposit)
        {
            decimal savings = 0.00M;
            savings = Deposit + getBalance();
            return savings;
        }

        //Base debit method
        public virtual decimal Debit(decimal Expenditure)
        {
            decimal spendings = 0.00M;   
                                  
            if (Expenditure > getBalance())
            {
                Console.WriteLine("Insufficient Funds");
            }
            else
            spendings = getBalance() - Expenditure;

            return spendings;
        }

        //Print method
        public virtual void PrintAccount()
        {            
            Console.WriteLine($"Account Name: {getAccountName()}");
            Console.WriteLine($"Account Number: {getAccountNumber()}");
            Console.WriteLine($"Balance: {getBalance().ToString("C2")}");          
        }

    }
}
