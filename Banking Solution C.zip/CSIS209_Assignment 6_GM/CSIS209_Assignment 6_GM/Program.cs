﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSIS209_Assignment_6_GM
{
    //CSIS 209, Assignment 6
    //Student: Gina Monti

    class Program
    {
        static void Main(string[] args)
        {

            //objects
            CheckingAccount montiChecking = new CheckingAccount();
            montiChecking.setAccountName("Monti-Checking");
            montiChecking.setAccountNumber(1);
            montiChecking.setBalance(1000);
            montiChecking.setFeeAmount(3);
            Console.WriteLine("Created checking account with $1,000 balance.");

            SavingsAccount montiSavings = new SavingsAccount();
            montiSavings.setAccountName("Monti-Savings");
            montiSavings.setAccountNumber(2);
            montiSavings.setBalance(2000);
            montiSavings.setInterestRate(0.05M);
            Console.WriteLine("Created savings account with $2,000 balance.");
            Console.Write("\n");

            //print object info
            montiChecking.PrintAccount();
            Console.Write("\n");
            montiSavings.PrintAccount();
            Console.WriteLine("\n");


            
            //method calls
            Console.WriteLine("Deposited $100 into checking account.");
            decimal savings = 0.00M;
            decimal Deposit = 100.00M;             
            savings = montiChecking.Credit(Deposit);
            montiChecking.setBalance(savings);            
            montiChecking.PrintAccount();
            Console.Write("\n");

            Console.WriteLine("Withdrew $50 from checking account");
            decimal spendings = 0.00M;
            decimal Expenditure = 50.00M;
            spendings = montiChecking.Debit(Expenditure);
            montiChecking.setBalance(spendings);            
            montiChecking.PrintAccount();
            Console.Write("\n");

            Console.WriteLine("Withdrew $6,000 from savings account.");
            decimal withdrawal = 6000;
            spendings = montiChecking.Debit(withdrawal); 
            montiChecking.PrintAccount();
            Console.Write("\n");

            Console.WriteLine("Deposited $3,000 into savings account");
            Deposit = 3000;
            savings = montiSavings.Credit(Deposit);
            montiSavings.setBalance(savings);           
            montiSavings.PrintAccount();
            Console.Write("\n");

            Console.WriteLine("Withdrew $200 from savings account.");
            withdrawal = 200;
            spendings = montiSavings.Debit(withdrawal);
            montiSavings.setBalance(spendings);
            montiSavings.PrintAccount();
            Console.Write("\n");

            Console.WriteLine("Calculate interest on savings.");
            decimal interestTotal = 0;
            interestTotal = montiSavings.CalculateInterest();
            montiSavings.setBalance(interestTotal);
            montiSavings.PrintAccount();
            Console.Write("\n");

            Console.WriteLine("Withdrew $10,000 from savings account.");
            withdrawal = 10000;
            montiSavings.Debit(withdrawal);          
            montiSavings.PrintAccount();
            Console.Write("\n");

            //pause application
            Console.WriteLine("Press the [enter] key to continue.");
            Console.ReadKey();
        }
    }
}
