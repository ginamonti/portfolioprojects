﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSIS209_Assignment_6_GM
{
    class CheckingAccount : Accounts

    {
        //properties
        private decimal FeeCharged;

        //constructors

        public CheckingAccount()       
            : base()
        {
            setFeeAmount(FeeCharged);
        }
        
        //setters and getters
        public void setFeeAmount(decimal setFeeAmount)
        {
            FeeCharged = setFeeAmount;

            if (FeeCharged < 0)
            {
                setFeeAmount = 0;
            }
            
        }

        public decimal getFeeAmount()
        {
            return FeeCharged;
        }

       

        //methods
        public override decimal Credit(decimal Deposit)
        {          
            decimal savings = 0;
            savings = (Deposit + base.getBalance()) - getFeeAmount();
            return savings;
        }

        //Debit method

        public override decimal Debit(decimal Expenditure)
        {
            decimal spendings = 0;
            spendings = (base.getBalance() - Expenditure) - getFeeAmount();

            return spendings;
        }

        //Print method
        public override void PrintAccount()
        {
            base.PrintAccount();
            Console.WriteLine($"Fee charged: {getFeeAmount().ToString("C")}");
        }


    }
}
