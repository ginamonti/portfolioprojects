//Pair.java: Pair class with type parameters
//CSIS 212-D01
//Citations: Deitel & Deitel, Java How to Program, 20.3 Generic Methods, 20.6 Generic Classes

//class statement
public class Pair<F, S> {

    //instance varibales
    private F fvar;
    private S svar;

//get methods
public F getF(){
    return fvar;
}

public S getS(){
    return svar;
}

//set methods
public void setF(F fvar){
    this.fvar = fvar;
}

public void setS(S svar){
    this.svar = svar;
}

}
