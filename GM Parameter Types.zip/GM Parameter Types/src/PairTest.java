//PairTest.java: Sets new Pair objects with integers and strings & prints the objects
//CSIS 212-D01
//Citations: Deitel & Deitel, Java How to Program, 20.3 Generic Methods, 20.6 Generic Classes

public class PairTest {

public static void main(String[] args){

    System.out.println("CSIS 312, Student: Gina Monti, Assignment 7");
    System.out.println();

    //new objects
    Pair<Integer, String> p1 = new Pair<Integer, String>();
    Pair<String, Integer> p2 = new Pair<String, Integer>();

    //first round of initializing
    p1.setF(37);
    p1.setS("First string");
    p2.setF("Second string");
    p2.setS(74);

    //print with get methods
    System.out.println("First round");
    System.out.printf("Pair 1 int: %d%nPair 1 string: %s", p1.getF(), p1.getS());
    System.out.println();
    System.out.printf("Pair 2 string: %s%nPair 2 int: %d", p2.getF(), p2.getS());
    System.out.println();
    System.out.println();

    //second round of initializing
    p1.setF(98);
    p1.setS("A new first string");
    p2.setF("A new second string");
    p2.setS(5);

    //print with get methods
    System.out.println("Second round");
    System.out.printf("Pair 1 int: %d%nPair 1 string: %s", p1.getF(), p1.getS());
    System.out.println();
    System.out.printf("Pair 2 string: %s%nPair 2 int: %d", p2.getF(), p2.getS());

}
}
