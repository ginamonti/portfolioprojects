//Program5GM.java: Randomly generates an array that is then filled into LinkedList, calculates sum and average
//CSIS 212-D01
//Citations: Deitel & Deitel, Java How to Program, 16.6.2 LinkedList, Sorting in Ascending Order

//imported packages
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Program5GM {

    //main method
    public static void main(String[] args){
        System.out.println("CSIS 312, Student: Gina Monti - Assignment 5");

        int [] array = new int[25];

        Random randomNum = new Random();

        //randomly assigns integers between 0 and 100 in an array
        for (int i = 0; i < array.length; i++ ){
            array[i] = randomNum.nextInt(100);
        }

        List<Integer> list = new LinkedList<>();

        //populates LinkedList list with array
        for (Integer listItem: array){
            list.add(listItem);
        }

        //sort and print
        Collections.sort(list);
        System.out.printf("Array list printed in order:%n%s", list);
        System.out.println();

        //calls Sum method and prints
        int sum = Sum(list);
        System.out.printf("Total sum of list: %d", sum);
        System.out.println();

        //calls Average method and prints
        float average = Average(sum, list);
        System.out.printf("Average of list: %.2f", average);
    }

    //orders list
    public static void PrintOrderedList (List<Integer> newList){
        for (Integer i : newList) {
            System.out.printf("%d ", i);
        }
    }

    //uses for iteration to get running total
    public static int Sum (List<Integer> thisList){
        int total = 0;
        for (Integer i : thisList){
            total += i;
        }
        return total;
    }

    //uses for iteration to find count and calculates total with float type
    public static float Average(int total, List<Integer> anotherList){
        int count = 0;
        for (Integer i : anotherList){
            count++;
        }
        float avg = (float) total / (float) count;
        return avg;
    }
}
